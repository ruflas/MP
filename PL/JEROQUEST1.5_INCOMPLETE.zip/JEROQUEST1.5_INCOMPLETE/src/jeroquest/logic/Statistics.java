package jeroquest.logic;


public class Statistics {
	int attacks,HeroesAttacks,MonstersAttacks,damage,HeroesDamageInflicted,MonstersDamageInflicted;
	
	public Statistics() {
		this.setAttacks(0);
		this.setDamage(0);
		this.setHeroesAttacks(0);
		this.setMonstersAttacks(0);
		this.setHeroesDamageInflicted(0);
		this.setMonstersDamageInflicted(0);
	}
	
	public Statistics(int attacks, int damage) {
		this.setAttacks(attacks);
		this.setDamage(damage);
	}

	public int getAttacks() {
		return attacks;
	}

	public void setAttacks(int attacks) {
		this.attacks = attacks;
	}

	public int getDamage() {
		return damage;
	}

	public void setDamage(int damage) {
		this.damage = damage;
	}
	
	public void incAttacks(int attacks) {
		this.setAttacks(this.getAttacks()+attacks);
	}
	
	public void incDamage(int damage) {
		this.setDamage(this.getDamage()+damage);
	}
	
	public int getHeroesAttacks() {
		return HeroesAttacks;
	}
	public int getHeroesDamageInflicted() {
		return HeroesDamageInflicted;
	}
	public int getMonstersAttacks() {
		return MonstersAttacks;
	}
	public int getMonstersDamageInflicted() {
		return MonstersDamageInflicted;
	}
	
	public void setHeroesAttacks(int heroesAttacks) {
		HeroesAttacks = heroesAttacks;
	}

	public void setMonstersAttacks(int monstersAttacks) {
		MonstersAttacks = monstersAttacks;
	}

	public void setHeroesDamageInflicted(int heroesDamageInflicted) {
		HeroesDamageInflicted = heroesDamageInflicted;
	}

	public void setMonstersDamageInflicted(int monstersDamageInflicted) {
		MonstersDamageInflicted = monstersDamageInflicted;
	}
	
	public void incHeroesAttacks(int n) {
		this.setHeroesAttacks(this.getHeroesAttacks()+n);
	}
	public void incMonstersAttacks(int n) {
		this.setMonstersAttacks(this.getMonstersAttacks()+n);
	}
	public void incHeroesDamageInflicted(int n) {
		this.setHeroesDamageInflicted(this.getHeroesDamageInflicted()+n);
	}
	public void incMonstersDamageInflicted(int n) {
		this.setMonstersDamageInflicted(this.getMonstersDamageInflicted()+n);
	}
	
	@Override
	public String toString() {
		return String.format("Number of Attacks: %d\n Number of Damage: %d\n Heroes Attacks: %d\n Monster Attacks: %d\n Heroes Damage Inflicted: %d\n Monsters Damage inflicted: %d\n",this.getAttacks(),this.getDamage(),this.getHeroesAttacks(),this.getMonstersAttacks(),this.getHeroesDamageInflicted(),this.getMonstersDamageInflicted());
	}
}
